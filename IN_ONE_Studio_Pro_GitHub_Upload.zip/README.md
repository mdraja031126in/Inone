# IN ONE Studio Pro
Upload all of these files to a GitHub repository, then open Actions -> Build APK -> Run workflow.
The APK appears under Artifacts when the run finishes.
